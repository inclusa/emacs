# The Plain v3.0

The Plain is a minimalist Jekyll theme, designed to focus on writing that really matters to you and your audience. Everything else is just a distraction. Nothing more other than useful and understandable information sharing. I have made a final update to this theme. This theme is suit best for personal blog type, but not limited to. P/S: This theme is originally inspired from Leonard Lamprecht's original [Jekyll theme](https://github.com/leo/leo.github.io) (thanks!).

[**Live Demo**](http://heiswayi.github.io/the-plain/)

### Screenshot

![The Plain Screenshot](http://i.imgur.com/8ZXhjfV.png)

### Philosophy

> Minimalism is a masterpiece of tranquility. -- Heiswayi Nrird

### License

[MIT](LICENSE.md)

### Credits

Many thanks to this theme [contributors](https://github.com/heiswayi/the-plain/graphs/contributors) that help fixing bugs or enhance this theme source code.
